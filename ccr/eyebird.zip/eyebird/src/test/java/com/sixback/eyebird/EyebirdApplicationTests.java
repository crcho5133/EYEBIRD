package com.sixback.eyebird;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EyebirdApplicationTests {

	@Test
	void contextLoads() {
	}

}
